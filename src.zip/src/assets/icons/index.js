import menu from "../icons/menu.svg";
import closeMenu from "../icons/closeMenu.svg";
import email from "../icons/email.svg";
import twitter from "../icons/twitter.svg";
import location from "../icons/location.svg";
import linkedin from "../icons/linkedin.svg"
import star from "../icons/star.svg"
import sun from "../icons/sun.svg"
import asleep from "../icons/moon.svg"

export {
    menu,
    closeMenu,
    email,
    location,
    twitter,
    star,
    linkedin,
    sun,
    asleep
}