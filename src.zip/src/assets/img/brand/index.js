import heroImg from "./heroImg.jpg"
import aboutVideo from "./about-vid.mp4"
import storyImg from "./storyImg.jpg"
import recycle from "./recycle.jpg"
import maintenance from "./maintenance.png"


export {
    heroImg,
    aboutVideo,
    storyImg,
    recycle,
    maintenance
}