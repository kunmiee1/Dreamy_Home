import Logo from "./logo.png";
import brand_logo from "./brand_logo.png";
import brand_logo_2 from "./brand_logo_2.png";
import project_1 from "./project_1.jpg"
import project_2 from "./project_2.jpg"
import project_3 from "./project_3.jpg"
import project_4 from "./project_4.jpg"
import icon from "./icon-arrow-down.png"
import arrow_slant from "./arrow_slant.png"
import custom_project from "./custom_project.jpg"


export {
    Logo,
    arrow_slant,
    brand_logo,
    brand_logo_2,
    project_1,
    project_2,
    project_3,
    project_4,
    custom_project
}

