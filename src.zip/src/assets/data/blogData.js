import { project_1, project_2 } from "../img";

export const blog = [
  {
    id: 1,
    date: "Tue 07 Feb 2020",
    title: "How interior design and architecture can work for seamless design",
    img: project_1
  },
  {
    id: 2,
    date: "Tue 07 Feb 2020",
    title: "Sustainable Architecture Takes Center Stage",
    img: project_2
  },
];
