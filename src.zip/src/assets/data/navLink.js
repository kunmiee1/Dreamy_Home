const navLink = [
    {
        id: 1,
        navName: "Home",
        navLink: ""
    },
    {
        id: 2,
        navName: "About",
        navLink: "about"
    },
    {
        id: 3,
        navName: "Services",
        navLink: "services"
    },
    {
        id: 4,
        navName: "Projects",
        navLink: "projects"
    },
    {
        id: 5,
        navName: "News",
        navLink: "news"
    },
]

export default navLink